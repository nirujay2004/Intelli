import eel
import wolframalpha
import pyttsx3
import speech_recognition

engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("voice", voices[1].id)
rate = engine.setProperty("rate",174)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def WolfRamAlpha(query):
    apikey = "45H2AR-5E5KX4L8TX"
    requester = wolframalpha.Client(apikey)
    requested = requester.query(query)

    try:
        answer = next(requested.results).text
        return answer
    except:
        speak("The value is not answerable")
# WolfRamAlpha()

@eel.expose
def Calc(query):
        Term = str(query)
        Term = Term.replace("intelli","")
        Term = Term.replace("multiply","*")
        Term = Term.replace("plus","+")
        Term = Term.replace("minus","-")
        Term = Term.replace("divide","/")

        Final = str(Term)
        try:
            result = WolfRamAlpha(Final)
            print(f"{result}")
            eel.DisplayMessage(result)
            speak(result)
        
        except:
            speak("The value is not answerable")
            eel.DisplayMessage("The value is not answerable")
        eel.ShowHood()
# Calc()
